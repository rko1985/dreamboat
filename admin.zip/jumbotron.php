
<div class="jumbotron h-100">
  <h1 class="display-4">Hello, Welcome to DreamBoat Finders!</h1>
  <p class="lead">A simple way to find the boat you are looking for...</p>
  <hr class="my-4">
  <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Exercitationem voluptatum quia placeat eaque cupiditate. Magnam natus nobis laboriosam eveniet neque quos, accusantium, vero tenetur exercitationem nesciunt sint maxime numquam ab!</p>
  <p class="lead text-center">Register or Login now to list your boat!</p>
  <p class="lead text-center">
    <a class="btn btn-primary btn-lg" href="login.php" role="button">Login</a> Or <a class="btn btn-primary btn-lg" href="register.php" role="button">Register</a>
  </p>
</div>